import time

def function(count):
    
    sum = 0
    for check in range(1, int(count/2+1)):
        if count % check == 0:
            sum += check
    if sum == count:
        return True
    else:
        return False




tal = int(input("Tal: "))
print(function(tal))

import time

for count in range(1, 10000):
    sum = 0
    for check in range(1, int(count/2+1)):
        if count % check == 0:
            sum += check
    if sum == count:
        print(count)

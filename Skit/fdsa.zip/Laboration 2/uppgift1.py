for j in range(17):
    print("*", end="")
print()

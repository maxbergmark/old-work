while 1:
    a = int(input("a: "))
    b = int(input("b: "))

    print("Kubsumma: ", a**3 + b**3)
    print()

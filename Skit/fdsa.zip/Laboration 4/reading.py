

fil = open('ordlista.txt',)

string = fil.read()
lista = string.split()
print(len(lista[0]))
